//#include<opencv2/imgcodecs.hpp>
//#include<opencv2/highgui.hpp>
//#include<opencv2/imgproc.hpp>
//#include<iostream>
//using namespace std;
//using namespace cv;
//float w = 600, h = 600;
//Mat matrix,imgwarp;
//void main()
//{
//	string path = "Resource/pubg.png";
//	Mat img = imread(path);
//	 
//	Point2f src[4] = { {167,277},{629,277},{170,947},{631,947} }; // pixel of that cordinate
//	Point2f dst[4] = { {0.0f,0.0f},{w,0.0f},{0.0f,h},{w,h} };     // 
//
//	for (int i = 0; i < 4; i++)
//	{
//		circle(img, src[i], 10, Scalar(0, 45, 136), FILLED);          // loop for check the cordinates of picture.
//	}
//
//	matrix = getPerspectiveTransform(src, dst);         // Different perspective for image from src to destination.
//	warpPerspective(img, imgwarp, matrix, Point(w, h));
//
//	
//
//	imshow("Image", img);
//	imshow("Imagewarp", imgwarp);
//	waitKey(0);
//}
