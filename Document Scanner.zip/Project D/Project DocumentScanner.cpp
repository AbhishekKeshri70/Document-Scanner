#include<iostream>
#include<opencv2/imgcodecs.hpp>
#include<opencv2/highgui.hpp>
#include<opencv2/imgproc.hpp>
using namespace std;
using namespace cv;
Mat imgGray, imgBlur, imgdia, imgCanny,getimage,imgOriginal,imgwarp;
vector<Point>intialPoints;
vector<Point>docpoints;
float w = 420, h = 596;

  Mat getperspective(Mat img2) 
  {
	  cvtColor(img2, imgGray, COLOR_BGR2Luv); // Image color changing.
	  	GaussianBlur(img2, imgBlur, Size(3, 3), 3, 0);
	  	Canny(imgBlur, imgCanny, 50, 50);
	  
	  	Mat kernel = getStructuringElement(MORPH_RECT,Size(7, 7));
	  	dilate(imgCanny, imgdia, kernel);
		return imgdia;
}

 vector<Point>getContours(Mat image)
  {
	  string objectype;
	  vector<vector<Point>>contours;
	  vector<Vec4i>heirarchy;
	  findContours(image, contours, heirarchy, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);
	  vector<vector<Point>>conpoly(contours.size());
	  vector<Rect>boundRect(contours.size());
	  
	  vector<Point>biggest;
	  double maxarea=0;
	  for (int i = 0; i < contours.size(); i++)
	  {
		  double area = contourArea(contours[i]);
		  cout << area << endl;
		  if (area > 2000)
		  {
			  float peri = arcLength(contours[i], true);
			  approxPolyDP(contours[i], conpoly[i], 0.02 * peri, true);
			//   for checking rectangle and area
			  if (area > maxarea && conpoly[i].size()==4)
			  {
				 // drawContours(imgOriginal, conpoly, i, Scalar(255, 0, 255),5);
				  biggest = { conpoly[i][0],conpoly[i][1] ,conpoly[i][2] ,conpoly[i][3] };
				  maxarea = area;
				 
			  }			 
		  }
	  }
	return biggest;
  }
 vector<Point> reorder(vector<Point>copoints)
 {
	 vector<Point>newpoints;
	 vector<int> SumPoints, SubPoints;
	 for (int i = 0; i < 4; i++)
	 {
		 SumPoints.push_back(copoints[i].x + copoints[i].y);
		 SubPoints.push_back(copoints[i].x - copoints[i].y);
	 }

	newpoints.push_back(copoints[min_element(SumPoints.begin() , SumPoints.end()) - SumPoints.begin()]); //0
	newpoints.push_back(copoints[max_element(SubPoints.begin(), SubPoints.end()) - SubPoints.begin()]);  //1
	newpoints.push_back(copoints[min_element(SubPoints.begin(), SubPoints.end()) - SubPoints.begin()]);  //2
	newpoints.push_back(copoints[max_element(SumPoints.begin(), SumPoints.end()) - SumPoints.begin()]);  //3

	
	

	return newpoints;
 }

 void draw(vector<Point>Points ,Scalar color)
 {
	 for (int i = 0; i< Points.size();i++)
	 {
		 circle(imgOriginal, Points[i], 3, color, FILLED);
 putText(imgOriginal, to_string(i), Points[i], FONT_HERSHEY_PLAIN, 2, color, 1);
	 }
 }

 Mat getwarp(Mat imgOriginal, vector<Point> docpointer, float w, float h)
 {
	 Point2f src[4] = { docpointer[0],docpointer[1], docpointer[2], docpointer[3]}; // pixel of that cordinate
	 	Point2f dst[4] = { {0.0f,0.0f},{w,0.0f},{0.0f,h},{w,h} }; 

	Mat matrix = getPerspectiveTransform(src, dst);         // Different perspective for image from src to destination.
	 	warpPerspective(imgOriginal, imgwarp, matrix, Point(w, h));
		return imgwarp;
 }

 //Importing Images..
int main()
{
	string path = "Resource/doc4.jpeg";
	imgOriginal = imread(path);            // Mat is data tyoe for handling images.
	//resize(imgOriginal, imgOriginal, Size(), 0.8, 0.8);
	
	// prespective....
    getimage = getperspective(imgOriginal);

	// contours of Image...
  intialPoints = getContours(getimage);

  // draw(intialPoints,Scalar(0,0,255));
 
  // fixing the Coordinates of image....
  docpoints = reorder(intialPoints);

  // draw(docpoints,Scalar(0,255,0));

   // Warp imaging...
  imgwarp= getwarp(imgOriginal, docpoints, w, h);

  Rect roi(8, 8, w - (2 * 8), h - (2 * 8));
  Mat imgCrop = imgwarp(roi);

	/*imshow("ImageDia", getimage);
	imshow("Image", imgOriginal);
	imshow("ImageWarp", imgwarp);*/
	imshow("Imagecrop", imgCrop);
	waitKey(0);
	return 0;
}