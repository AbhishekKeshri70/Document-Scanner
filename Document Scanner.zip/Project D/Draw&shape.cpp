//#include<opencv2/imgcodecs.hpp>
//#include<opencv2/highgui.hpp>
//#include<opencv2/imgproc.hpp>
//#include<iostream>
//using namespace std;
//using namespace cv;
//// Importing Images..
//int main()
//{
//	Mat img(512, 512, CV_8UC3, Scalar(255, 255, 255));
//	circle(img, Point(256, 256), 178, Scalar(0, 69, 255),FILLED);
//	rectangle(img, Point(132, 236), Point(386, 296), Scalar(255, 255, 255), 1);
//	putText(img, "Ram jee", Point(137, 262), FONT_HERSHEY_SIMPLEX, 1,Scalar(255, 0, 69), 1);
////	imshow("Image", img);
//	imshow("Image Circle", img);
//	waitKey(0);
//	return 0;
//}