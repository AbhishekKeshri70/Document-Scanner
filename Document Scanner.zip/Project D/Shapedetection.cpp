//#include<opencv2/imgcodecs.hpp>
//#include<opencv2/highgui.hpp>
//#include<opencv2/imgproc.hpp>
//#include<iostream>
//using namespace std;
//using namespace cv;
//void getcontours(Mat imgdia, Mat img2)
//{
//	string objectype;
//	vector<vector<Point>>contours;
//	vector<Vec4i>heirarchy;
//	findContours(imgdia, contours, heirarchy, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);
//
//	for (int i = 0; i < contours.size(); i++)
//	{
//		
//		double area = contourArea(contours[i]);
//		cout << area << endl;
//		if (area > 3000)
//		{
//			vector<vector<Point>>conpoly(contours.size());
//			vector<Rect>boundrect(contours.size());
//
//			float peri = arcLength(contours[i], true);
//			approxPolyDP(contours[i], conpoly[i], 0.02 * peri, true);
//			boundrect[i] = boundingRect(conpoly[i]);
//
//			int obj = (int)conpoly[i].size();
//
//			if (obj == 3)
//			{
//				objectype = "Tri";
//			}
//			else if (obj == 4)
//			{
//				objectype = "Rect";
//			}
//			if (obj == 6)
//			{
//				objectype = "Hexa";
//			}
//			else if(obj>6)
//				objectype = "Circle";
//
//			rectangle(img2, boundrect[i].tl(), boundrect[i].br(), Scalar(255, 255, 255), 1);
//			drawContours(img2, contours, i, Scalar(255, 0, 255), 2);
//			putText(img2, objectype, { boundrect[i].x, boundrect[i].y-5 },FONT_HERSHEY_SIMPLEX, 1, Scalar(255, 0, 69), 1);
//		}
//	}
//}
//int main()
//{
//	string path = "Resource/shape.png";
//	Mat img2 = imread(path);            // Mat is data tyoe for handling images.
//	Mat imgGray, imgBlur, imgCanny, imgdia, imgerode;
//		
//		cvtColor(img2, imgGray,COLOR_BGR2Luv); // Image color changing.
//		GaussianBlur(img2, imgBlur, Size(3, 3), 3, 0);
//		Canny(imgBlur, imgCanny, 100, 200);
//	
//		Mat kernel = getStructuringElement(MORPH_RECT,Size(5, 5));
//		dilate(imgCanny, imgdia, kernel);
//	
//		getcontours(imgdia, img2);
//		imshow("Image", img2);
//
//	waitKey(0);
//	return 0;
//}