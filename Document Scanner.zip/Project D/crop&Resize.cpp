//#include<opencv2/imgcodecs.hpp>
//#include<opencv2/highgui.hpp>
//#include<opencv2/imgproc.hpp>
//#include<iostream>
//using namespace std;
//using namespace cv;
//int main()
//{
//
//	string path = "Resource/kya.jpg";
//	Mat img = imread(path);
//	Mat imgResize, imgCrop;
//	Rect roi(100, 100, 600, 600);
//	imgCrop = img(roi);
//	resize(img, imgResize, Size(), 0.8, 0.8);
//	imshow("Image", img);
//	imshow("Image Resize", imgResize);
//	imshow("Image Crop", imgCrop);
//	waitKey(0);
//	return 0;
//}